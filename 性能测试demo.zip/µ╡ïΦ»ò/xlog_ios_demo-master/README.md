# xlog_ios_demo

Tencent mars xlog iOS demo

xlog文件 解析工具 也可以使用我编写的 [桌面解码工具XlogDecoder](https://github.com/JerryFans/mars_xlog_decoder_gui) 无需调用python脚本。
