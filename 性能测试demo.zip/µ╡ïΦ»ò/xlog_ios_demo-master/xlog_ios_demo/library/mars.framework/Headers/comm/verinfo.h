
#ifndef Mars_verinfo_h
#define Mars_verinfo_h

#define MARS_REVISION ""
#define MARS_PATH ""
#define MARS_URL ""
#define MARS_BUILD_TIME "2022-03-05 17:41:21"
#define MARS_TAG ""

#endif
