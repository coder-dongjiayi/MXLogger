//
//  SceneDelegate.h
//  xlog_ios_demo
//
//  Created by 逸风 on 2022/3/5.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

