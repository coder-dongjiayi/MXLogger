//
//  mmap_sink.hpp
//  MXLoggerCore
//
//  Created by 董家祎 on 2022/5/29.
//

#ifndef mmap_sink_hpp
#define mmap_sink_hpp

#include <stdio.h>
#include "memory_mmap.hpp"
#include "log_msg.hpp"
namespace mxlogger{
namespace sinks {
class mmap_sink{
public:
    
    mmap_sink(const std::string &dir_path,policy::storage_policy policy);
    
    ~mmap_sink(){};
    
    void log(const details::log_msg &msg);
    
    // 设置日志等级
    void set_level(level::level_enum log_level);
    
    // 判断是否应该打印日志
     bool should_log(level::level_enum msg_level);
    

    void flush();
private:
    std::atomic_int level_{level::debug};
    
    std::shared_ptr<memory_mmap> mmap_;
    std::string filename_;
    
    bool create_dir_(const std::string &path);
    void handle_date_(policy::storage_policy policy);
};



}
}
#endif /* mmap_sink_hpp */
